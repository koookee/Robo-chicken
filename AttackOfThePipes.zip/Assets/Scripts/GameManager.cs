﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameManager : MonoBehaviour
{
    public TextMeshProUGUI Score;
    public GameObject OnScreenText;
    public GameObject OnScreenText2;
    public GameObject OnScreenText3;
    public GameObject OnScreenText4;
    public GameObject OnScreenText5;
    public GameObject Boss;
    public SpawnManager SpawnManagerScript;
    public PlayerController PlayerController;
    public int scoreVal;
    // Start is called before the first frame update
    void Start()
    {
        PlayerController = GameObject.Find("Player").GetComponent<PlayerController>();
        SpawnManagerScript = GameObject.Find("SpawnManager").GetComponent<SpawnManager>();
        //  SpawnManagerScript.BossSpawner();
        SpawnManagerScript.BossSpawner();
    }
    IEnumerator ShowText(int i)
    {
        if(i == 1) 
        {
            OnScreenText.SetActive(true);
            yield return new WaitForSeconds(5);//5
            OnScreenText.SetActive(false);
        }
        if(i == 2)
        {
            OnScreenText2.SetActive(true);
            yield return new WaitForSeconds(5);
            OnScreenText2.SetActive(false);
        }
        if (i == 3)
        {
            OnScreenText3.SetActive(true);
            yield return new WaitForSeconds(5);
            OnScreenText3.SetActive(false);
        }
        if(i == 4)
        {
            OnScreenText4.SetActive(true);
            yield return new WaitForSeconds(5);
            OnScreenText4.SetActive(false);
            OnScreenText5.SetActive(true);
            yield return new WaitForSeconds(7);
            OnScreenText5.SetActive(false);
            PlayerController.BossSpawned = true;
            SpawnManagerScript.BossSpawner();
        }


    }

    public void updateScore()
    {
        Score.text = "Score:" + PlayerController.score;
    }
    public void OnScreen(int i)
    {
     StartCoroutine(ShowText(i));
    }
    // Update is called once per frame
    void Update()
    {
        updateScore();
        
    }

}
