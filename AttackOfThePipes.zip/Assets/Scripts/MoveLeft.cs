﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveLeft : MonoBehaviour
{
    public GameObject trap;
    private float speed = 3.0f;
    public PlayerController PlayerControllerScript;
    
    
    
    // Start is called before the first frame update
    void Start()
    {
         PlayerControllerScript = GameObject.Find("Player").GetComponent<PlayerController>();  
    }

    // Update is called once per frame
    void Update()
    {
        if (!PlayerControllerScript.gameOver)
        {
            transform.Translate(Vector3.left * Time.deltaTime * speed * PlayerControllerScript.gameSpeedMultiplier); 
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Barrier"))
        {
            Destroy(trap.gameObject);
        }
    }
}
