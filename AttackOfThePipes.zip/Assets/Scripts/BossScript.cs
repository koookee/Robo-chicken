﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossScript : MonoBehaviour
{
    public PlayerController PlayerControllerScript;
    public GameManager GameManagerScript;
    private float speed = 1f;
    public float health = 10;
    Vector3 endPos = new Vector3(-219f, -8.35f, -0.9f);
    // Start is called before the first frame update

    void Start()
    {
        PlayerControllerScript = GameObject.Find("Player").GetComponent<PlayerController>();
        GameManagerScript = GameObject.Find("GameManager").GetComponent<GameManager>();
        
    }
    
   

    // Update is called once per frame
    void Update()
    {
       if(transform.position.x > endPos.x)
        {
            transform.Translate(Vector3.left * Time.deltaTime * speed);    
        }
    }
    
}
